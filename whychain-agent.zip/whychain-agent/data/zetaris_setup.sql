CREATE LIGHTNING DATABASE WHYCHAIN_REST DESCRIBE BY "WhyChain synthetic supply chain data";

CREATE SCHEMASTORE CONTAINER whychain;

CREATE LIGHTNING REST TABLE carrier_otp_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/carrier_otp",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW carrier_otp WITH CONTAINER whychain AS
SELECT r.carrier AS carrier, r.week AS week, r.otp_pct AS otp_pct
FROM whychain_rest.carrier_otp_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE chokepoint_daily_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/chokepoint_daily",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW chokepoint_daily WITH CONTAINER whychain AS
SELECT r.chokepoint AS chokepoint, r.day AS day, r.transits_7d AS transits_7d, r.baseline AS baseline, r.source AS source
FROM whychain_rest.chokepoint_daily_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE eta_forecast_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/eta_forecast",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW eta_forecast WITH CONTAINER whychain AS
SELECT r.po AS po, r.snapshot AS snapshot, r.eta_days AS eta_days, r.model_version AS model_version
FROM whychain_rest.eta_forecast_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE feature_effect_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/feature_effect",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW feature_effect WITH CONTAINER whychain AS
SELECT r.feature AS feature, r.days_per_unit AS days_per_unit, r.description AS description
FROM whychain_rest.feature_effect_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE feed_status_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/feed_status",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW feed_status WITH CONTAINER whychain AS
SELECT r.feed AS feed, r.age_min AS age_min, r.max_age_min AS max_age_min
FROM whychain_rest.feed_status_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE forecast_features_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/forecast_features",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW forecast_features WITH CONTAINER whychain AS
SELECT r.po AS po, r.snapshot AS snapshot, r.feature AS feature, r.value AS value
FROM whychain_rest.forecast_features_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE gauge_readings_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/gauge_readings",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW gauge_readings WITH CONTAINER whychain AS
SELECT r.station AS station, r.day AS day, r.cm AS cm
FROM whychain_rest.gauge_readings_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE incidents_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/incidents",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW incidents WITH CONTAINER whychain AS
SELECT r.id AS id, r.ts AS ts, r.source AS source, r.po AS po, r.text AS text
FROM whychain_rest.incidents_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE insurance_holds_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/insurance_holds",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW insurance_holds WITH CONTAINER whychain AS
SELECT r.po AS po, r.status AS status, r.days AS days
FROM whychain_rest.insurance_holds_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE lane_relations_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/lane_relations",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW lane_relations WITH CONTAINER whychain AS
SELECT r.po AS po, r.entity AS entity, r.kind AS kind
FROM whychain_rest.lane_relations_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE port_wait_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/port_wait",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW port_wait WITH CONTAINER whychain AS
SELECT r.port AS port, r.day AS day, r.wait_days AS wait_days
FROM whychain_rest.port_wait_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE route_options_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/route_options",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW route_options WITH CONTAINER whychain AS
SELECT r.po AS po, r.label AS label, r.channel AS channel, r.days AS days, r.extra_usd AS extra_usd, r.risk AS risk, r.status AS status
FROM whychain_rest.route_options_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE shipments_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/shipments",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW shipments WITH CONTAINER whychain AS
SELECT r.po AS po, r.bu AS bu, r.origin AS origin, r.dest AS dest, r.commodity AS commodity
FROM whychain_rest.shipments_rest
LATERAL VIEW explode(rows) AS r;

CREATE LIGHTNING REST TABLE weather_alerts_rest FROM WHYCHAIN_REST REQUEST(
    endpoint "http://host.docker.internal:8787/weather_alerts",
    method "get",
    response_type "json",
    http_encoding "URLENCODED"
) HEADER (
) BODY ();

CREATE SCHEMASTORE VIEW weather_alerts WITH CONTAINER whychain AS
SELECT r.port AS port, r.day AS day, r.alert AS alert
FROM whychain_rest.weather_alerts_rest
LATERAL VIEW explode(rows) AS r;
