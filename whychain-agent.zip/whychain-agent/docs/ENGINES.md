# Swapping in the official Meterless engines

The files in `src/engines/` are local stand-ins. To use the official engines:
1. `git clone https://github.com/Meterless/Meterless vendor/meterless` (Apache-2.0; keep their NOTICE).
2. Read their `docs/` for the World Model, H-MEM and Markovian engine interfaces.
3. Re-implement `WorldModel`, `hmem` and `Scratchpad` as thin adapters that call the vendored engine with the same method names used in `src/agent.ts` (`ingest`, `relate`, `recall`, `write`, `add`, `carry`).
4. Run each engine's own conformance runner and save the output to `evidence/`. Only then write "conformance N/N" in the README.
5. Mark every deviation in a `NOTICE.md`.
Judges score "how effectively the solution uses the sponsors' technology". Competing entries report engine conformance from Meterless's own runners, so this step matters.
