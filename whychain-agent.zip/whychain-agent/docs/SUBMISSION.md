# Submission kit (deadline 27 Oct 2026, 23:45 UTC, via HackOS)

## Checklist
- [ ] Track 02 selected. Register/confirm team on HackOS.
- [ ] Development tools disclosed honestly (editor, AI coding assistants, what you reviewed and tested). Cursor is optional; confirm in HackOS Official Rules section 05/06 that nothing changed.
- [ ] `npm run smoke` passes against real Zetaris and Nightshift.
- [ ] Zetaris running with all tables registered; `npm start` works with LIVE banner (green).
- [ ] Nightshift is the only provider; screenshot of its Providers tab showing NVIDIA (hide keys).
- [ ] Official engines vendored, conformance output saved in `evidence/`.
- [ ] `npm run benchmark` run LIVE; `evidence/` and `logs/` committed; README table filled from it.
- [ ] `.env` not committed; `.env.example` has placeholders only.
- [ ] Demo video 1 to 4 minutes (script below), deck, public repo, sponsor-technology explanation.

## Scoring (100 points; Impact is 30)
Impact, technical execution, creativity, demo clarity, usability, and effective use of sponsor technology. Show the thing running, not slides.

## Demo script (3:30)
0:00 Problem: chokepoints failing together, planners get a number with no reason (one sentence, one stat).
0:20 Live banner green. Ask "why did PO4471 move 11 days". Show exact split bars and the Zetaris query behind each figure.
1:10 The rumour: "typhoon closed Ningbo". Show it rejected with the weather-alert query returning 0.
1:30 Planted instruction in a news item: quarantined, no action created.
1:50 PO6033: only part explained. Agent says needs_review and refuses to guess. Say why this beats a fluent story.
2:20 Ablations: untick Zetaris (unknowable), untick Evaluator (rumour accepted). One sentence per sponsor on what it contributes.
2:50 Second run: H-MEM recalls the earlier case and reports what changed. Ledger intact.
3:10 Close: action gate, role access (analyst cannot see Agri), what ships next (PortWatch live feed).

## Deck outline (8 slides)
1 Problem and user. 2 Why current forecasts fail. 3 Agent loop (Planner, Executor, Evaluator). 4 Sponsor tech map with ablations. 5 Evidence table (real numbers). 6 Safety: rumours, injections, RBAC. 7 Demo screenshots. 8 Next steps.
