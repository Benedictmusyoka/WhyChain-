# Getting Zetaris connected (work down this list, stop when it works)

## 0. Is Zetaris itself up?
- In the `zetaris-platform` folder: `docker compose ps`. Every service should be Up. Start with `docker compose up -d`. Never run `docker compose down -v` (it destroys the metastore and keys).
- Open the UI (usually http://localhost:3000), sign in, open the **SQL Editor**, run `SELECT 7 AS seven;`. If this fails, the problem is the install, not this repo. Ask Zetaris or the hackathon support channel.

## 1. Point the repo at the right address and auth
Copy `.env.example` to `.env`. Two routes exist; use one:
| Route | Set | Address |
|---|---|---|
| proxy (what Zetaris getting-started helpers use) | `ZETARIS_BASE_URL` | the UI address, e.g. http://localhost:3000 |
| rest | `ZETARIS_ROUTE=rest`, `ZETARIS_REST_URL` | the API address, often http://localhost:8888/api/v1.0 |

Do not put a raw API port in `ZETARIS_BASE_URL`. `ZETARIS_ORG_ID` is a number (1 on a local install).
Auth: create a key under **Management > API Tokens** (shown once) and set `ZETARIS_API_KEY`. If you get "Api token is not allowed", use `ZETARIS_AUTH_MODE=login` with `ZETARIS_USERNAME` and `ZETARIS_PASSWORD` instead.
Then run `npm run smoke`. It prints the route and a hint for each failure. Add `ZETARIS_DEBUG=true` to see raw responses (share them, without secrets, when asking for help).

## 2. Load the WhyChain tables
Zetaris cannot read files on your laptop, so the tables are served over HTTP and registered with SQL.
1. `npm run data` then, in a second terminal, `npm run silos` (serves data/silos on :8787).
2. `npm run setup:zetaris` writes `data/zetaris_setup.sql`. Paste each statement into the SQL Editor **one at a time**, in order, and wait for each result. (Or `npm run setup:zetaris -- --run` once smoke passes.)
3. Check: `SELECT count(*) FROM whychain.shipments;` returns 3.
- Zetaris runs in Docker, so it reaches your machine at `host.docker.internal`. On Linux add `extra_hosts: ["host.docker.internal:host-gateway"]` to the Zetaris compose service, or set `SILO_HOST=http://<your-LAN-IP>:8787` before step 2.
- On a shared event instance, use your assigned database and container names: set `ZETARIS_LIGHTNING_DB` and `ZETARIS_SCHEMA`.
- If a view fails on a column name such as `day`, `text`, `status` or `source`, rename that column in `src/data/generate.ts` and `src/domain.ts`, regenerate, and register again.

## 3. Go live
Remove `LOCAL_DATA=true` and `LLM_STUB=true` from `.env`, run `npm run smoke` (all PASS), `npm start`, and look for the green LIVE banner.

## 4. If it still will not connect
Say so honestly in the submission: the agent runs end to end on its own data layer interface, Zetaris integration is implemented and unit-tested against a mock, and live verification could not be completed. Do not show the red NOT LIVE banner as if it were live.
