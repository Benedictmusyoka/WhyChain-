// Produces the evidence table: every case plus ablations, with ground-truth comparison.
// Run LIVE (Zetaris + Nightshift) and commit evidence/. Offline runs are labelled and are not evidence.
import fs from "node:fs";
import "./env.ts";
import { explain } from "./agent.ts";
import { hmem } from "./engines/hmem.ts";
const truth = JSON.parse(fs.readFileSync("data/ground_truth.json", "utf8"));
const POS = ["PO4471", "PO7102", "PO6033"];
const rows: any[] = []; let backends: any = {};
for (const po of POS) {
  for (const ablate of [[], ["zetaris"], ["evaluator"], ["hmem"], ["world"]]) {
    hmem.reset();
    if (ablate[0] === "hmem") await explain(po); // so memory exists to be ablated
    const r: any = await explain(po, { ablate });
    backends = r.backends;
    const t = truth[po];
    const splitOk = r.verdict !== "unknowable" && Object.entries(t.drivers).every(([k, v]) => r.causes?.find((c: any) => c.feature === k && String(c.status).startsWith("supported"))?.days === v) && r.unexplained_days === t.residual;
    const prompt = (r.trace as any[]).filter((x) => x.step === "LLM").length;
    rows.push({ po, ablated: ablate.join("+") || "none", verdict: r.verdict, confidence: r.confidence ?? "-", split_matches_truth: splitOk, rejected: (r.rejected ?? []).join(",") || "-", accepted_unverified: (r.accepted_unverified ?? []).join(",") || "-", quarantined: r.quarantined ?? 0, context_entities: r.context?.length ?? 0, memory_hit: !!r.memory_hit, queries: r.stats.queries, llm_calls: prompt, tokens_in: r.stats.tokens_in, tokens_out: r.stats.tokens_out, largest_carry_chars: r.stats.largest_carry_chars });
  }
}
const live = backends.data === "zetaris" && backends.llm === "meterless-nightshift";
fs.writeFileSync("evidence/benchmark.json", JSON.stringify({ ran_at: new Date().toISOString(), backends, live, rows }, null, 1));
const cols = Object.keys(rows[0]);
const md = `# Benchmark ${live ? "(LIVE: Zetaris + Meterless Nightshift)" : "(OFFLINE STAND-INS. NOT EVIDENCE. Rerun with live services.)"}\n\nRan ${new Date().toISOString()}. Data: ${backends.data}. LLM: ${backends.llm}.\n\n| ${cols.join(" | ")} |\n|${cols.map(() => "---").join("|")}|\n${rows.map((r) => `| ${cols.map((c) => r[c]).join(" | ")} |`).join("\n")}\n`;
fs.writeFileSync("evidence/BENCHMARK.md", md);
console.log(md);
