// IMF PortWatch ingestion: real satellite-AIS chokepoint transit counts, public ArcGIS FeatureServer.
// Method (same idea as public "chokepoint pressure" dashboards): current = mean of the latest 7 daily
// totals; baseline = mean daily total over calendar 2025; deviation = current / baseline - 1.
// Citation required by PortWatch: "Sources: UN Global Platform; IMF PortWatch (portwatch.imf.org)".
// NOTE: written without network access to the service. Field names are handled defensively; run it once,
// read data/portwatch_snapshot.json, and adjust FIELDS below if your output looks wrong.
import fs from "node:fs";

const BASE = "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/Daily_Chokepoints_Data/FeatureServer/0/query";
const FIELDS = { name: ["portname", "chokepoint"], date: ["date", "Date"], total: ["n_total"], parts: ["n_container", "n_dry_bulk", "n_general_cargo", "n_roro", "n_tanker"] };
// Labels used by the agent. The Black Sea corridor is proxied by Bosporus transits.
export const NAME_MAP: [RegExp, string][] = [
  [/suez/i, "Suez"], [/hormuz/i, "Hormuz"], [/bosphorus|bosporus/i, "BlackSea"], [/cape of good hope/i, "Cape"],
  [/bab.?el.?mandeb|bab.?al.?mandab/i, "BabAlMandeb"], [/panama/i, "Panama"], [/malacca/i, "Malacca"],
];
export interface Row { name: string; day: string; total: number }
const pick = (a: any, keys: string[]) => keys.map((k) => a[k]).find((v) => v !== undefined && v !== null);

export function normalize(attrs: any): Row | null {
  const raw = String(pick(attrs, FIELDS.name) ?? "");
  const hit = NAME_MAP.find(([re]) => re.test(raw));
  const d = pick(attrs, FIELDS.date);
  if (!hit || d === undefined) return null;
  const total = pick(attrs, FIELDS.total) ?? FIELDS.parts.reduce((s, k) => s + Number(attrs[k] ?? 0), 0);
  const day = typeof d === "number" ? new Date(d).toISOString().slice(0, 10) : String(d).slice(0, 10);
  return Number.isFinite(Number(total)) ? { name: hit[1], day, total: Number(total) } : null;
}

export function compute(rows: Row[]) {
  const by = new Map<string, Row[]>();
  for (const r of rows) (by.get(r.name) ?? by.set(r.name, []).get(r.name)!).push(r);
  const out: { chokepoint: string; day: string; transits_7d: number; baseline: number; source: string }[] = [];
  for (const [name, rs] of by) {
    const byDay = new Map<string, number>();
    for (const r of rs) byDay.set(r.day, (byDay.get(r.day) ?? 0) + r.total); // sums sub-rows if a day is split
    const days = [...byDay.keys()].sort();
    const y25 = days.filter((d) => d.startsWith("2025"));
    if (y25.length < 300 || days.length < 7) continue; // not enough history for a fair baseline
    const mean = (xs: number[]) => xs.reduce((s, x) => s + x, 0) / xs.length;
    const last7 = days.slice(-7).map((d) => byDay.get(d)!);
    out.push({ chokepoint: name, day: days.at(-1)!, transits_7d: Math.round(mean(last7) * 10) / 10, baseline: Math.round(mean(y25.map((d) => byDay.get(d)!)) * 10) / 10, source: "IMF PortWatch" });
  }
  return out;
}

async function fetchAll(where: string) {
  const rows: Row[] = [];
  for (let page = 0, offset = 0; page < 60; page++) {
    const u = new URL(BASE);
    u.search = new URLSearchParams({ where, outFields: "*", returnGeometry: "false", orderByFields: "date ASC", resultOffset: String(offset), resultRecordCount: "2000", f: "json" }).toString();
    const res = await fetch(u, { signal: AbortSignal.timeout(60_000) });
    const body: any = await res.json();
    if (body.error) throw new Error(`PortWatch ${body.error.code}: ${body.error.message}`);
    const feats: any[] = body.features ?? [];
    for (const f of feats) { const r = normalize(f.attributes ?? {}); if (r) rows.push(r); }
    if (!feats.length || !body.exceededTransferLimit) break;
    offset += feats.length;
  }
  return rows;
}

export async function refresh() {
  let rows: Row[];
  try { rows = await fetchAll("date >= timestamp '2025-01-01 00:00:00'"); } catch { rows = await fetchAll("1=1"); }
  const snap = compute(rows);
  if (!snap.length) throw new Error("PortWatch returned no usable chokepoints. Check FIELDS and NAME_MAP in src/data/portwatch.ts against the raw response.");
  fs.mkdirSync("data", { recursive: true });
  fs.writeFileSync("data/portwatch_snapshot.json", JSON.stringify({ fetched_at: new Date().toISOString(), rows: snap }, null, 1));
  return snap;
}

if (process.argv[1]?.endsWith("portwatch.ts")) {
  const snap = await refresh();
  for (const r of snap) console.log(`${r.chokepoint.padEnd(12)} ${r.day}  7d ${String(r.transits_7d).padStart(6)}  baseline ${String(r.baseline).padStart(6)}  ${Math.round((r.transits_7d / r.baseline - 1) * 100)}%`);
  const { build } = await import("./generate.ts");
  build("data/whychain.db", { live: true });
  console.log("Rebuilt data/whychain.db and data/silos/ with the live PortWatch snapshot. Re-register chokepoint_daily and feed_status in Zetaris if you use the silos.");
}
