// Generates (and optionally runs) the Zetaris statements that expose the silo tables as queryable views.
// Pattern from the Zetaris getting-started "first dataset": LIGHTNING DATABASE + SCHEMASTORE CONTAINER +
// LIGHTNING REST TABLE + SCHEMASTORE VIEW with LATERAL VIEW explode. On a shared event instance use your
// ASSIGNED names: set ZETARIS_LIGHTNING_DB and ZETARIS_SCHEMA (container) in .env.
import fs from "node:fs";
import "../env.ts";

export function buildSql(silos: Record<string, string[]>, opts = { db: process.env.ZETARIS_LIGHTNING_DB ?? "WHYCHAIN_REST", container: process.env.ZETARIS_SCHEMA ?? "whychain", host: process.env.SILO_HOST ?? "http://host.docker.internal:8787" }) {
  const out = [`CREATE LIGHTNING DATABASE ${opts.db} DESCRIBE BY "WhyChain synthetic supply chain data";`, `CREATE SCHEMASTORE CONTAINER ${opts.container};`];
  for (const [t, cols] of Object.entries(silos)) {
    out.push(`CREATE LIGHTNING REST TABLE ${t}_rest FROM ${opts.db} REQUEST(\n    endpoint "${opts.host}/${t}",\n    method "get",\n    response_type "json",\n    http_encoding "URLENCODED"\n) HEADER (\n) BODY ();`);
    out.push(`CREATE SCHEMASTORE VIEW ${t} WITH CONTAINER ${opts.container} AS\nSELECT ${cols.map((c) => `r.${c} AS ${c}`).join(", ")}\nFROM ${opts.db.toLowerCase()}.${t}_rest\nLATERAL VIEW explode(rows) AS r;`);
  }
  return out;
}
if (process.argv[1]?.endsWith("registerZetaris.ts")) {
  const silos: Record<string, string[]> = {};
  for (const f of fs.readdirSync("data/silos")) silos[f.replace(".json", "")] = Object.keys(JSON.parse(fs.readFileSync(`data/silos/${f}`, "utf8"))[0] ?? {});
  const sql = buildSql(silos);
  fs.writeFileSync("data/zetaris_setup.sql", sql.join("\n\n") + "\n");
  console.log(`Wrote data/zetaris_setup.sql (${sql.length} statements). Paste them into the Zetaris SQL Editor one at a time, or rerun with --run.`);
  if (process.argv.includes("--run")) {
    const { query } = await import("../zetaris.ts");
    for (const s of sql) { try { await query(s); console.log("OK  ", s.split("\n")[0].slice(0, 90)); } catch (e: any) { console.log("FAIL", s.split("\n")[0].slice(0, 90), "\n     ", e.message); if (!process.argv.includes("--continue")) process.exit(1); } }
  }
}
