// Serves each synthetic table as {"rows":[...]} so Zetaris can read it as a REST table.
// Inside Docker, Zetaris reaches this server at http://host.docker.internal:8787 (Linux: add the host-gateway mapping).
import http from "node:http";
import fs from "node:fs";
const PORT = Number(process.env.SILO_PORT ?? 8787);
http.createServer((req, res) => {
  const name = (req.url ?? "/").split("?")[0].replace(/^\/+/, "");
  const f = `data/silos/${name}.json`;
  if (!/^[a-z_]+$/.test(name) || !fs.existsSync(f)) { res.writeHead(404).end("not found"); return; }
  res.writeHead(200, { "content-type": "application/json" }).end(JSON.stringify({ rows: JSON.parse(fs.readFileSync(f, "utf8")) }));
}).listen(PORT, "0.0.0.0", () => console.log(`Silo server on :${PORT} (tables: ${fs.readdirSync("data/silos").map((x) => x.replace(".json", "")).join(", ")})`));
