// Corroboration tests: for each cause the model attributes the change to, ask the data an independent question.
import { T } from "./sql.ts";
export interface Corr { label: string; feed: string; sql: () => string; params?: Record<string, string>; test: (rows: any[], v1: number) => { supports: boolean; note: string } }
const ratio = (name: string) => (rows: any[]) => {
  const r = rows[0]; if (!r) return { supports: false, note: `no ${name} data` };
  const dev = Math.round((r.transits_7d / r.baseline - 1) * 100);
  return { supports: r.transits_7d / r.baseline < 0.6, note: `${name} transits ${r.transits_7d} vs baseline ${r.baseline} (${dev}%)` };
};
const chk = (name: string) => () => `select transits_7d, baseline from ${T("chokepoint_daily")} where chokepoint='${name}' order by day desc limit 1`;
const wait = (port: string) => ({ sql: () => `select wait_days from ${T("port_wait")} where port='${port}' order by day desc limit 1`, test: (rows: any[], v1: number) => ({ supports: !!rows[0] && Math.abs(rows[0].wait_days - v1) <= 0.5, note: `${port} wait ${rows[0]?.wait_days ?? "n/a"} days` }) });
export const CORR: Record<string, Corr> = {
  suez_closed: { label: "Suez unavailable, Cape routing", feed: "portwatch", sql: chk("Suez"), test: ratio("Suez") },
  hormuz_overland_leg: { label: "Hormuz closure forces overland leg", feed: "portwatch", sql: chk("Hormuz"), test: ratio("Hormuz") },
  blacksea_diversion: { label: "Black Sea corridor diversion", feed: "ais_blacksea", sql: chk("BlackSea"), test: ratio("BlackSea") },
  ngb_wait_days: { label: "Ningbo port wait above normal", feed: "port_ops", ...wait("NGB") },
  khor_fakkan_wait_days: { label: "Khor Fakkan congestion", feed: "port_ops", ...wait("KFK") },
  kaub_low_water_idx: { label: "Rhine low water at Kaub", feed: "gauges", sql: () => `select cm from ${T("gauge_readings")} where station='KAUB' order by day desc limit 1`, test: (r) => ({ supports: !!r[0] && r[0].cm < 78, note: `Kaub gauge ${r[0]?.cm ?? "n/a"} cm` }) },
  carrier_otp_drop_pts: { label: "Carrier on-time performance drop", feed: "carrier", sql: () => `select week, otp_pct from ${T("carrier_otp")} where carrier='CARRIER_A' order by week desc limit 2`, test: (r) => ({ supports: r.length === 2 && r[1].otp_pct - r[0].otp_pct >= 4, note: r.length === 2 ? `OTP ${r[1].otp_pct}% to ${r[0].otp_pct}%` : "no OTP data" }) },
  war_risk_hold: { label: "War-risk insurance hold", feed: "port_ops", sql: () => `select status, days from ${T("insurance_holds")} where po=:po`, test: (r) => ({ supports: r[0]?.status === "ACTIVE", note: `insurance hold ${r[0]?.status ?? "none"}` }) },
  insurer_hold_days: { label: "Insurer hold on departure", feed: "port_ops", sql: () => `select status, days from ${T("insurance_holds")} where po=:po`, test: (r) => ({ supports: r[0]?.status === "ACTIVE", note: `insurance hold ${r[0]?.status ?? "none"}, ${r[0]?.days ?? 0} days` }) },
  // A claim that arrives as free text from a social feed. It must be corroborated before it counts as a cause.
  ningbo_typhoon: { label: "Typhoon closed Ningbo terminals (rumour)", feed: "port_ops", sql: () => `select count(*) as c from ${T("weather_alerts")} where port='NGB' and day>='2026-10-19'`, test: (r) => ({ supports: Number(r[0]?.c) > 0, note: `weather alerts for Ningbo since 19 Oct: ${r[0]?.c ?? 0}` }) },
};
