// H-MEM: working / episodic / semantic tiers plus a hash-chained trust ledger.
// STAND-IN with the same concepts as the Meterless H-MEM engine (see docs/ENGINES.md to swap in the official one).
import fs from "node:fs";
import { createHash } from "node:crypto";
const FILE = process.env.HMEM_FILE ?? "memory/hmem.json";
interface Store { working: any[]; episodic: any[]; semantic: any[]; ledger: any[] }
const load = (): Store => { try { return JSON.parse(fs.readFileSync(FILE, "utf8")); } catch { return { working: [], episodic: [], semantic: [], ledger: [] }; } };
const save = (s: Store) => { fs.mkdirSync("memory", { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(s, null, 1)); };
export const hmem = {
  reset() { save({ working: [], episodic: [], semantic: [], ledger: [] }); },
  recall(po: string) {
    const s = load();
    const last = [...s.episodic].reverse().find((e) => e.po === po);
    return last ? { hit: true, last, rejected: s.semantic.filter((x) => x.po === po && x.kind === "rejected_claim").map((x) => x.cause) } : { hit: false as const, last: null, rejected: [] as string[] };
  },
  write(po: string, episode: any, rejected: string[]) {
    const s = load();
    s.episodic.push({ po, ts: new Date().toISOString(), ...episode });
    for (const cause of rejected) if (!s.semantic.some((x) => x.po === po && x.cause === cause)) s.semantic.push({ po, kind: "rejected_claim", cause });
    const prev = s.ledger.at(-1)?.hash ?? "genesis";
    const entry = { po, summary: episode.summary, prev };
    s.ledger.push({ ...entry, hash: createHash("sha256").update(JSON.stringify(entry)).digest("hex").slice(0, 16) });
    save(s);
  },
  verifyLedger() {
    let prev = "genesis";
    for (const e of load().ledger) {
      const h = createHash("sha256").update(JSON.stringify({ po: e.po, summary: e.summary, prev })).digest("hex").slice(0, 16);
      if (e.prev !== prev || e.hash !== h) return false;
      prev = e.hash;
    }
    return true;
  },
};
