// Markovian-style bounded carryover: each reasoning chunk sees only a small scratchpad, never the whole history.
// STAND-IN for the Meterless Markovian engine (see docs/ENGINES.md); the cap and largest-carry metric mirror its idea.
export class Scratchpad {
  private facts: string[] = [];
  largest = 0;
  chunks = 0;
  constructor(private cap = 500) {}
  add(fact: string) {
    this.facts.push(fact); this.chunks++;
    while (this.facts.join("; ").length > this.cap && this.facts.length > 1) this.facts.shift();
    this.largest = Math.max(this.largest, this.facts.join("; ").length);
  }
  carry() { return this.facts.join("; "); }
}
