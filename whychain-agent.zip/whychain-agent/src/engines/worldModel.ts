// World Model: entities, per-source timestamped facts, relations, idempotent ingest, conflict detection.
// STAND-IN with the same concepts as the Meterless World Model engine. To use the official engine,
// vendor github.com/Meterless/Meterless and swap this file's internals (see docs/ENGINES.md).
export interface Fact { entity: string; key: string; value: string; source: string; ts: string }
export class WorldModel {
  private facts = new Map<string, Fact>();
  private rel = new Map<string, Set<string>>();
  ingest(f: Fact) { this.facts.set(`${f.entity}|${f.key}|${f.source}`, f); } // idempotent by (entity,key,source)
  relate(from: string, to: string) { (this.rel.get(from) ?? this.rel.set(from, new Set()).get(from)!).add(to); }
  related(from: string) { return [...(this.rel.get(from) ?? [])]; }
  state(entity: string) { return [...this.facts.values()].filter((f) => f.entity === entity); }
  conflicts() {
    const by = new Map<string, Fact[]>();
    for (const f of this.facts.values()) (by.get(`${f.entity}|${f.key}`) ?? by.set(`${f.entity}|${f.key}`, []).get(`${f.entity}|${f.key}`)!).push(f);
    return [...by.values()].filter((g) => new Set(g.map((x) => x.value)).size > 1).map((g) => g);
  }
  size() { return this.facts.size; }
}
