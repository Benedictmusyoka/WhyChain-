// AI provider: Meterless Nightshift (OpenAI-compatible runtime) is the ONLY provider.
// Models are NVIDIA Nemotron, configured in Nightshift's Providers tab:
//   fast lane  nemotron-3.5-lightning-30b-a3b  (extraction, cheap steps)
//   deep lane  nemotron-3-ultra-550b-a55b      (planning, final explanation)
// LLM_STUB=true swaps in a deterministic offline stub for tests only; every trace line says so.
import { env, flag } from "./env.ts";

export type Lane = "fast" | "deep";
export interface LlmResult { text: string; model: string; tokens_in: number; tokens_out: number; receipt: Record<string, string> }

export async function chat(role: string, lane: Lane, system: string, user: string): Promise<LlmResult> {
  if (flag("LLM_STUB")) return stub(role, user);
  const model = lane === "fast" ? env("METERLESS_MODEL", "nvidia/nemotron-3.5-lightning-30b-a3b") : env("METERLESS_DEEP_MODEL", "nvidia/nemotron-3-ultra-550b-a55b");
  const res = await fetch(env("METERLESS_BASE_URL", "http://127.0.0.1:8088/v1").replace(/\/$/, "") + "/chat/completions", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + env("METERLESS_RUNTIME_TOKEN"),
      "Content-Type": "application/json",
      "meterless-app": env("METERLESS_APP", "whychain"),
      "meterless-scope": env("METERLESS_SCOPE", "open-agent-hackathon"),
    },
    body: JSON.stringify({ model, temperature: 0, messages: [{ role: "system", content: system }, { role: "user", content: user }] }),
    signal: AbortSignal.timeout(120_000),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Nightshift ${res.status}: ${text.slice(0, 300)}`);
  const body = JSON.parse(text);
  const receipt: Record<string, string> = {};
  res.headers.forEach((v, k) => { if (k.includes("meterless")) receipt[k] = v; }); // keep whatever receipt headers Nightshift returns
  return { text: body.choices?.[0]?.message?.content ?? "", model, tokens_in: body.usage?.prompt_tokens ?? 0, tokens_out: body.usage?.completion_tokens ?? 0, receipt };
}

export function json<T>(text: string, fallback: T): T {
  const m = text.match(/\{[\s\S]*\}/);
  try { return m ? JSON.parse(m[0]) : fallback; } catch { return fallback; }
}

function stub(role: string, user: string): LlmResult {
  const u = JSON.parse(user);
  let text = "";
  if (role === "planner") text = JSON.stringify({ hypotheses: [...(u.prior ?? []), ...u.candidates.filter((c: string) => !(u.prior ?? []).includes(c))] });
  else if (role === "extractor") text = JSON.stringify({ claims: /typhoon/i.test(u.incident_text) && /ningbo/i.test(u.incident_text) ? [{ cause: "ningbo_typhoon" }] : [] });
  else text = u.template;
  return { text, model: "stub (offline, NOT Nemotron)", tokens_in: 0, tokens_out: 0, receipt: {} };
}
