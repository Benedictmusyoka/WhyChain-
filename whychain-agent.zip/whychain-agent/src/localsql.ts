// OFFLINE STAND-IN for Zetaris (SQLite). Used only when LOCAL_DATA=true, for tests and development.
import { DatabaseSync } from "node:sqlite";
let db: DatabaseSync | null = null;
const open = () => (db ??= new DatabaseSync("data/whychain.db", { readOnly: true }));
export async function query(sql: string, params: Record<string, string | number> = {}) {
  return open().prepare(sql).all(params) as Record<string, unknown>[];
}
export function tables(): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  for (const t of open().prepare("select name from sqlite_master where type='table'").all() as any[])
    out[t.name] = (open().prepare(`pragma table_info(${t.name})`).all() as any[]).map((c) => c.name);
  return out;
}
