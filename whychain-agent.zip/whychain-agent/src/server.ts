import http from "node:http";
import fs from "node:fs";
import { explain } from "./agent.ts";
import { env } from "./env.ts";
import { hmem } from "./engines/hmem.ts";
const PORT = Number(env("PORT", "3040"));
http.createServer(async (req, res) => {
  const u = new URL(req.url ?? "/", "http://x");
  try {
    if (u.pathname === "/api/run") {
      const r = await explain(u.searchParams.get("po") ?? "PO4471", { role: (u.searchParams.get("role") as any) ?? "planner", ablate: (u.searchParams.get("ablate") ?? "").split(",").filter(Boolean), goal: (u.searchParams.get("goal") as any) ?? "bal" });
      res.writeHead(200, { "content-type": "application/json" }).end(JSON.stringify(r));
    } else if (u.pathname === "/api/ledger") {
      res.writeHead(200, { "content-type": "application/json" }).end(JSON.stringify({ intact: hmem.verifyLedger() }));
    } else if (u.pathname === "/api/reset") { hmem.reset(); res.writeHead(200).end("ok"); }
    else res.writeHead(200, { "content-type": "text/html" }).end(fs.readFileSync("web/index.html"));
  } catch (e: any) { res.writeHead(500, { "content-type": "application/json" }).end(JSON.stringify({ error: String(e.message) })); }
}).listen(PORT, () => console.log(`WhyChain on http://localhost:${PORT}`));
