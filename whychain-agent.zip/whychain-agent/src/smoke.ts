// Run first, with your real .env: confirms Zetaris answers SQL and both Nemotron lanes answer through Nightshift.
import "./env.ts";
import * as zetaris from "./zetaris.ts";
import { route, hint } from "./zetaris.ts";
import { chat } from "./llm.ts";
import { env } from "./env.ts";
let bad = 0;
const step = async (name: string, fn: () => Promise<string>) => { try { console.log(`PASS ${name}: ${await fn()}`); } catch (e: any) { bad++; console.log(`FAIL ${name}: ${e.message}`); const h = hint(e.message); if (h) console.log(`  -> ${h}`); } };
console.log(`Zetaris route: ${route()}  base: ${process.env.ZETARIS_BASE_URL ?? process.env.ZETARIS_REST_URL}  auth: ${process.env.ZETARIS_AUTH_MODE ?? "apikey"}`);
await step("Zetaris SQL", async () => JSON.stringify(await zetaris.query("select 1 as ok")));
await step("Zetaris schema", async () => `${(await zetaris.query(`SHOW TABLES IN ${env("ZETARIS_SCHEMA", "whychain")}`)).length} tables visible (expect 13+)`);
for (const lane of ["fast", "deep"] as const)
  await step(`Nightshift ${lane} lane`, async () => { const r = await chat("smoke", lane, "Reply with the JSON {\"ok\":true} and nothing else.", "ping"); return `${r.model}, ${r.tokens_in}+${r.tokens_out} tokens, receipt headers: ${JSON.stringify(r.receipt)}`; });
console.log(bad ? `\n${bad} check(s) failed. Fix these before demo (see README, "Verify before demo").` : "\nAll sponsor connections work. Now run: npm run benchmark");
process.exit(bad ? 1 : 0);
