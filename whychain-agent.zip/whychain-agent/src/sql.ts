import { env, flag } from "./env.ts";
import * as zetaris from "./zetaris.ts";
import * as local from "./localsql.ts";

export const dataBackend = () => (flag("LOCAL_DATA") ? "local-sqlite (offline stand-in, NOT Zetaris)" : "zetaris");
export const T = (t: string) => (flag("LOCAL_DATA") ? t : `${env("ZETARIS_SCHEMA", "whychain")}.${t}`);
const lit = (v: string | number) => {
  if (typeof v === "number") return String(v);
  if (!/^[A-Za-z0-9_\-\.]+$/.test(v)) throw new Error("unsafe SQL parameter");
  return `'${v}'`;
};
export async function query(sql: string, params: Record<string, string | number> = {}) {
  if (flag("LOCAL_DATA")) return local.query(sql, params);
  return zetaris.query(sql.replace(/:([a-z_0-9]+)/g, (_, k) => lit(params[k])));
}
export async function catalog(): Promise<Record<string, string[]>> {
  if (flag("LOCAL_DATA")) return local.tables();
  const out: Record<string, string[]> = {};
  const schema = env("ZETARIS_SCHEMA", "whychain");
  for (const t of await zetaris.query(`SHOW TABLES IN ${schema}`)) {
    const name = String(t.tableName ?? t.table_name ?? Object.values(t).find((v) => typeof v === "string") ?? "");
    const cols = await zetaris.query(`DESCRIBE ${schema}.${name}`);
    out[name] = cols.map((c) => String(c.col_name ?? c.column_name ?? Object.values(c)[0]));
  }
  return out;
}
