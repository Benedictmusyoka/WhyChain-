// Zetaris client. Two HTTP routes and two auth modes, because local and event installs differ:
//   ZETARIS_ROUTE=proxy  UI origin (ZETARIS_BASE_URL, e.g. http://localhost:3000)
//                        POST /api/proxy/sql-editor/sqls/run-query {sql, limit}   (route used by Zetaris getting-started helpers)
//   ZETARIS_ROUTE=rest   REST API (ZETARIS_REST_URL, e.g. http://localhost:8888/api/v1.0)
//                        POST /sql-editor/sqls/run {queryId, sql, source, limit}
//   ZETARIS_AUTH_MODE=apikey (default, Bearer ZETARIS_API_KEY) | login (POST {BASE}/api/auth/login -> idToken)
// Default route is proxy when ZETARIS_BASE_URL is set, otherwise rest. Set ZETARIS_DEBUG=true to print raw responses.
import { randomUUID } from "node:crypto";
import { env } from "./env.ts";

let cached: { token: string; exp: number } | null = null;
export const route = () => process.env.ZETARIS_ROUTE ?? (process.env.ZETARIS_BASE_URL ? "proxy" : "rest");
const dbg = (...a: unknown[]) => { if (process.env.ZETARIS_DEBUG === "true") console.error("[zetaris]", ...a); };

async function http(url: string, init: RequestInit) {
  try { return await fetch(url, { ...init, signal: AbortSignal.timeout(60_000) }); }
  catch (e: any) { throw new Error(`Cannot reach ${url}: ${e.cause?.code ?? e.message}`); }
}
async function token(): Promise<string> {
  if ((process.env.ZETARIS_AUTH_MODE ?? "apikey") !== "login") return env("ZETARIS_API_KEY");
  if (cached && cached.exp > Date.now()) return cached.token;
  const res = await http(env("ZETARIS_BASE_URL").replace(/\/$/, "") + "/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: env("ZETARIS_USERNAME"), password: env("ZETARIS_PASSWORD") }) });
  const text = await res.text(); dbg("login", res.status, text.slice(0, 300));
  if (!res.ok) throw new Error(`Zetaris login ${res.status}: ${text.slice(0, 200)}`);
  const b = JSON.parse(text); const t = b.idToken ?? b.token ?? b.accessToken;
  if (!t) throw new Error("Zetaris login returned no idToken. Run with ZETARIS_DEBUG=true and check the response.");
  cached = { token: t, exp: Date.now() + 10 * 60_000 };
  return t;
}
export function parseRows(body: any): Record<string, unknown>[] {
  const data = body?.data ?? body?.rows ?? body?.result ?? body?.results ?? body;
  if (!Array.isArray(data)) throw new Error("Unrecognised Zetaris response shape: " + JSON.stringify(body).slice(0, 300));
  if (!data.length || !Array.isArray(data[0])) return data;
  const cols = (body.columns ?? body.schema ?? body.headers ?? body.fields ?? []).map((c: any) => (typeof c === "string" ? c : c.name ?? c.columnName ?? c.col_name));
  if (!cols.length) throw new Error("Zetaris returned rows without column names: " + JSON.stringify(body).slice(0, 300));
  return data.map((r: unknown[]) => Object.fromEntries(cols.map((c: string, i: number) => [c, r[i]])));
}
export async function query(sql: string): Promise<Record<string, unknown>[]> {
  const statement = sql.trim().replace(/;$/, "");
  const proxy = route() === "proxy";
  const url = proxy ? env("ZETARIS_BASE_URL").replace(/\/$/, "") + "/api/proxy/sql-editor/sqls/run-query" : env("ZETARIS_REST_URL").replace(/\/$/, "") + "/sql-editor/sqls/run";
  const body = proxy ? { sql: statement, limit: 1000 } : { queryId: randomUUID(), sql: statement, source: "SqlEditor", limit: 1000 };
  const res = await http(url, { method: "POST", headers: { Authorization: "Bearer " + (await token()), "X-Org-ID": env("ZETARIS_ORG_ID", "1"), "X-Request-ID": randomUUID(), "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const text = await res.text(); dbg(res.status, url, text.slice(0, 500));
  if (!res.ok) throw new Error(`Zetaris ${res.status} from ${url}: ${text.slice(0, 300)}`);
  return parseRows(JSON.parse(text));
}
export function hint(msg: string) {
  if (/Cannot reach|ECONNREFUSED|ENOTFOUND/.test(msg)) return "Zetaris is not answering at that address. Run `docker compose ps` in zetaris-platform and check the UI loads (usually http://localhost:3000). Use the UI address in ZETARIS_BASE_URL, or the REST address in ZETARIS_REST_URL (often http://localhost:8888/api/v1.0).";
  if (/not allowed|401|403/.test(msg)) return "Auth rejected. Try ZETARIS_AUTH_MODE=login with ZETARIS_USERNAME and ZETARIS_PASSWORD (some local bundles reject API tokens), or create a fresh key under Management > API Tokens.";
  if (/404/.test(msg)) return "Wrong route. Switch ZETARIS_ROUTE between proxy (UI origin) and rest (API address). Do not point the proxy route at a raw API port.";
  if (/shape|column names/.test(msg)) return "Connected, but the response format differs. Rerun with ZETARIS_DEBUG=true and adjust parseRows in src/zetaris.ts.";
  return "";
}
