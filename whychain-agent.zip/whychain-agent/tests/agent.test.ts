import { test, before } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
process.env.LOCAL_DATA = "true"; process.env.LLM_STUB = "true"; process.env.HMEM_FILE = "memory/test.json";
const { build } = await import("../src/data/generate.ts");
const { explain } = await import("../src/agent.ts");
const { hmem } = await import("../src/engines/hmem.ts");
const truth = () => JSON.parse(fs.readFileSync("data/ground_truth.json", "utf8"));
before(() => { build(); hmem.reset(); });

test("PO4471: exact split matches ground truth, rumour rejected, injection quarantined", async () => {
  const r: any = await explain("PO4471"); const t = truth().PO4471;
  assert.equal(r.verdict, "explained"); assert.equal(r.total_days, t.total);
  for (const [k, v] of Object.entries(t.drivers)) assert.equal(r.causes.find((c: any) => c.feature === k)?.days, v, k);
  assert.equal(r.unexplained_days, t.residual);
  assert.deepEqual(r.rejected, t.rejected);
  assert.equal(r.quarantined, 1); assert.ok(r.arithmetic_ok); assert.ok(r.narrative_faithful);
  assert.ok(!r.actions.some((a: any) => /immediately|ignore/i.test(a.action)), "injected text must not create an action");
});
test("PO7102: multi-chokepoint case explained with medium confidence", async () => {
  const r: any = await explain("PO7102"); const t = truth().PO7102;
  for (const [k, v] of Object.entries(t.drivers)) assert.equal(r.causes.find((c: any) => c.feature === k)?.days, v, k);
  assert.equal(r.unexplained_days, t.residual); assert.equal(r.confidence, "medium");
});
test("PO6033: uncorroborated cause is rejected and the agent escalates instead of guessing", async () => {
  const r: any = await explain("PO6033"); const t = truth().PO6033;
  assert.equal(r.verdict, "needs_review"); assert.equal(r.confidence, "low");
  assert.deepEqual(r.rejected, t.rejected); assert.equal(r.unexplained_days, t.residual);
  assert.match(r.actions[0].status, /Recommendation only/);
});
test("RBAC: analyst cannot see the Agri shipment", async () => {
  const r: any = await explain("PO6033", { role: "analyst" }); assert.equal(r.verdict, "denied");
});
test("Ablation: without the data layer the agent says unknowable", async () => {
  const r: any = await explain("PO4471", { ablate: ["zetaris"] }); assert.equal(r.verdict, "unknowable");
});
test("Ablation: without the evaluator the rumour is accepted unverified", async () => {
  const r: any = await explain("PO4471", { ablate: ["evaluator"] });
  assert.ok(r.accepted_unverified.includes("ningbo_typhoon")); assert.equal(r.rejected.length, 0);
});
test("H-MEM: second run recalls the first and the ledger is intact", async () => {
  hmem.reset(); await explain("PO4471"); const r: any = await explain("PO4471");
  assert.ok(r.memory_hit); assert.ok(r.since_last); assert.ok(hmem.verifyLedger());
  const r2: any = await explain("PO4471", { ablate: ["hmem"] }); assert.equal(r2.memory_hit, false);
});
test("World Model: ablation removes lane context", async () => {
  const a: any = await explain("PO4471"); const b: any = await explain("PO4471", { ablate: ["world"] });
  assert.ok(a.context.length > 0); assert.equal(b.context.length, 0);
});
