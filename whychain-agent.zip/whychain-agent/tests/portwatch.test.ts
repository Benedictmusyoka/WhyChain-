import { test } from "node:test";
import assert from "node:assert/strict";
import { normalize, compute } from "../src/data/portwatch.ts";

const days = (start: string, n: number) => Array.from({ length: n }, (_, i) => new Date(Date.parse(start) + i * 864e5).toISOString().slice(0, 10));
test("normalize maps PortWatch names and sums vessel-type counts", () => {
  const r = normalize({ portname: "Suez Canal", date: Date.parse("2026-10-20"), n_container: 5, n_dry_bulk: 3, n_general_cargo: 1, n_roro: 1, n_tanker: 2 });
  assert.deepEqual(r, { name: "Suez", day: "2026-10-20", total: 12 });
  assert.equal(normalize({ portname: "Somewhere Else", date: 0, n_total: 4 }), null);
});
test("compute: 7-day mean against the 2025 baseline", () => {
  const rows = [...days("2025-01-01", 365).map((d) => ({ name: "Suez", day: d, total: 70 })), ...days("2026-10-18", 7).map((d) => ({ name: "Suez", day: d, total: 22 }))];
  const [r] = compute(rows);
  assert.equal(r.chokepoint, "Suez"); assert.equal(r.transits_7d, 22); assert.equal(r.baseline, 70); assert.equal(r.day, "2026-10-24");
});
test("compute skips chokepoints without enough 2025 history", () => {
  assert.equal(compute(days("2025-01-01", 30).map((d) => ({ name: "Suez", day: d, total: 70 }))).length, 0);
});
