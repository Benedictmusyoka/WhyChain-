import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { AddressInfo } from "node:net";
import { parseRows } from "../src/zetaris.ts";
const { buildSql } = await import("../src/data/registerZetaris.ts");

// These tests use a MOCK server to check the client's request shape and parsing. The mock is not Zetaris.
test("proxy route with login auth sends bearer idToken and parses column/data rows", async () => {
  const seen: any = {};
  const srv = http.createServer((req, res) => {
    let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => {
      if (req.url === "/api/auth/login") return res.end(JSON.stringify({ idToken: "TOK" }));
      seen.url = req.url; seen.auth = req.headers.authorization; seen.org = req.headers["x-org-id"]; seen.body = JSON.parse(b);
      res.end(JSON.stringify({ columns: ["ok"], data: [[1]] }));
    });
  }).listen(0);
  const port = (srv.address() as AddressInfo).port;
  Object.assign(process.env, { ZETARIS_BASE_URL: `http://127.0.0.1:${port}`, ZETARIS_ROUTE: "proxy", ZETARIS_AUTH_MODE: "login", ZETARIS_USERNAME: "u", ZETARIS_PASSWORD: "p", ZETARIS_ORG_ID: "1" });
  const { query } = await import("../src/zetaris.ts");
  assert.deepEqual(await query("select 1 as ok;"), [{ ok: 1 }]);
  assert.equal(seen.url, "/api/proxy/sql-editor/sqls/run-query"); assert.equal(seen.auth, "Bearer TOK"); assert.equal(seen.org, "1"); assert.equal(seen.body.sql, "select 1 as ok");
  srv.close();
});
test("parseRows accepts object rows and rejects unknown shapes with a useful message", () => {
  assert.deepEqual(parseRows({ rows: [{ a: 1 }] }), [{ a: 1 }]);
  assert.throws(() => parseRows({ nope: 1 }), /Unrecognised/);
});
test("registration SQL follows the getting-started pattern for every table", () => {
  const sql = buildSql({ shipments: ["po", "bu"], eta_forecast: ["po", "eta_days"] }, { db: "WHYCHAIN_REST", container: "whychain", host: "http://h:8787" });
  assert.equal(sql.length, 2 + 2 * 2);
  assert.match(sql[2], /CREATE LIGHTNING REST TABLE shipments_rest FROM WHYCHAIN_REST REQUEST\(/);
  assert.match(sql[3], /CREATE SCHEMASTORE VIEW shipments WITH CONTAINER whychain AS\nSELECT r\.po AS po, r\.bu AS bu\nFROM whychain_rest\.shipments_rest\nLATERAL VIEW explode\(rows\) AS r;/);
});
